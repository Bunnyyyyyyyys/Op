﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalonKrasotyApp.ModelEF;

namespace SalonKrasotyApp
{
    static class Program
    {
        public static BeautySalonDB db = new BeautySalonDB();
        [STAThread]
        static void Main()
        {
            if (!db.Database.Exists())
            {
                MessageBox.Show("Нет базы данных!");
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainFrm());
        }
    }
}
