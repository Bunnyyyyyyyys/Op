﻿using SalonKrasotyApp.ModelEF;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalonKrasotyApp
{
    public partial class AddEditProductFrm : Form
    {
        public Product prod { get; set; }

        public AddEditProductFrm()
        {
            InitializeComponent();
        }

        private void AddEditProductFrm_Load(object sender, EventArgs e)
        {
            manufacturerBindingSource.DataSource = Program.db.Manufacturers.ToList();

            if (prod != null)
            {
                productBindingSource.Add(prod);
                // показываем в PictureBox изображение продукции
                if (prod.MainImagePath != "") // если есть путь к файлу с фотографией
                    ProductPic.Image = Image.FromFile(prod.MainImagePath.Trim());
                else
                    // если фотографии нет показываем заглушку из свойств
                    ProductPic.Image = Properties.Resources.beauty_logo;

                Text = "Изменение выбранной продукции";
                TitleLbl.Text = "Редактирование товара - " + prod.Title;
            }
            else
            {
                // создаем новый объект Product - продукции
                Product prod1 = new Product();
                // задаем начальную картинку для новой продукции
                prod1.MainImagePath = "";
                ProductPic.Image = Properties.Resources.beauty_logo;
                // добавляем созданный объект в промежуточный объект (но не в модель)
                productBindingSource.Add(prod1);
                //productBindingSource.AddNew();
                TitleLbl.Text = "Добавление нового товара ";
            }
        }

        string filePath = "";

        private void titleTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void descriptionTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void iDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void mainImagePathTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void manufacturerIDComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void costTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void isActiveCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ProductPic_Click(object sender, EventArgs e)
        {

        }

        private void SelectPictBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Файлы картинок|*.jpg;*.jpeg;*.png;";

            ofd.InitialDirectory += @"..\Товары салона красоты\";

            DialogResult dr = ofd.ShowDialog();
            if (dr == DialogResult.OK)
            {
                string file = "";  
                int n = ofd.FileName.IndexOf("Товары салона красоты");
                if (n < 0)
                {       
                    FileInfo fileInf = new FileInfo(ofd.FileName);
                    file = ofd.InitialDirectory + fileInf.Name;

                    fileInf.CopyTo(file);

                    filePath = @"Товары салона красоты\" + fileInf.Name;
                }
                else
                {  
                    filePath = ofd.FileName.Substring(n);
                }

                mainImagePathTextBox.Text = filePath;
                ProductPic.Image = Image.FromFile(file);
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (titleTextBox.Text == "" || costTextBox.Text == "")
            {
                MessageBox.Show("Заданы не все данные товара!");
                return;
            }

            if (prod == null)
            {
                prod = (Product)productBindingSource.Current;
                Program.db.Products.Add(prod);
            }
            
            prod.MainImagePath = filePath;

            try
            {
                Program.db.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
