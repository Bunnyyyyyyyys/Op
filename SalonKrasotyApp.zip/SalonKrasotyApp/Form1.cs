﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalonKrasotyApp.ModelEF;

namespace SalonKrasotyApp
{
    public partial class MainFrm : Form
    {
        static int nDataInPage = 20;  
        static int nButtons = 4;   
     
     
        int nPageAll = 0;      
        int nPageFirst = 1;   
        int nPageCurrent = 1;   
        Button[] btnsList = new Button[nButtons];   
   
        List<Product> lstFormatData = new List<Product>();
        static public List<int> lstSelectedIdData = new List<int>();

        public MainFrm()
        {
            InitializeComponent();
        }
        private void MainFrm_Load(object sender, EventArgs e)
        {
            btnsList[0] = button1;
            btnsList[1] = button2;
            btnsList[2] = button3;
            btnsList[3] = button4;
            nPageCurrent = 1;
            SortCmb.SelectedIndex = 0;
            List<string> lstFiltr = Program.db.Manufacturers.
                    Select(a => a.Name).OrderBy(s => s).ToList();
            lstFiltr.Insert(0, "Все производители");
            FiltrCmb.DataSource = lstFiltr;
            FiltrCmb.SelectedIndex = 0;

            manufacturerBindingSource.DataSource = Program.db.Manufacturers.ToList();
            Podgotovka();
        }

        
        string filtr = "Все производители";  
        string sort = "Без сортировки"; 
        string search = "";  

        public void Podgotovka()
        {
            lstFormatData = Program.db.Products.ToList();        

            if (filtr != "Все производители")
            {
                lstFormatData = lstFormatData.
                    Where(p => (p.Manufacturer.Name == filtr)).ToList();
            }
            if (search != "")
            {   
                lstFormatData = lstFormatData.
                    Where(p => p.Title.Contains(search)).ToList();
                if (lstFormatData.Count == 0)
                {
                    MessageBox.Show("Cтрока " + search + " нигде не найдена!");
                }
            }
            
            if (sort != "Без сортировки")
            {
                if (sort == "Название")
                {  
                    if (!DownChk.Checked)
                        lstFormatData = lstFormatData.OrderBy(p => p.Title).ToList();
                    else
                        lstFormatData = lstFormatData.
                                OrderByDescending(p => p.Title).ToList();
                }
                if (sort == "Стоимость")
                {  
                    if (!DownChk.Checked)
                        lstFormatData = lstFormatData.OrderBy(p => p.Cost).ToList();
                    else
                        lstFormatData = lstFormatData.
                                OrderByDescending(p => p.Cost).ToList();
                }
            }
            nPageFirst = nPageCurrent = 1; 
            nPageAll = lstFormatData.Count() / nDataInPage;
            if (nPageAll * nDataInPage < lstFormatData.Count())
                nPageAll++;
            ShowData();
            ShowButtons(nPageFirst, nPageCurrent);
        }
        private void ShowData()
        {         
            int nDataMax = lstFormatData.Count();     
            int beginProdNumber = (nPageCurrent - 1) * nDataInPage;        
            int endProdNumber = beginProdNumber + nDataInPage;
            if (endProdNumber > nDataMax) endProdNumber = nDataMax;

            productBindingSource.List.Clear();

            for (int j = beginProdNumber; j < endProdNumber; j++)
            {
                productBindingSource.List.Add(lstFormatData[j]);
            }

            
            RangeLbl.Text = $"Товары с {beginProdNumber + 1} по " +
                        $"{endProdNumber} (из всего {lstFormatData.Count()})";
        }


        int filtrCount = 0;  


        int sortCount = 0;
        
                
        void ShowButtons(int nPageFirst, int nPageCurrent)
        {
            for (int i = 0; i < nButtons; i++)
            {
                int nPage = nPageFirst + i; 
                btnsList[i].Text = nPage.ToString();
                btnsList[i].BackColor = Color.White;

                btnsList[i].Visible = true;

                if (nPage <= nPageAll)
                { 
                    if (nPage == nPageCurrent) 
                        btnsList[i].BackColor = Color.LightBlue;
                }
                else
                {  
                    btnsList[i].Visible = false;
                }
            }
            if (nPageCurrent == 1) 
            {
                LeftBtn.Enabled = false;
                LeftBtn.BackColor = Color.LightGray;
            }
            else
            {
                LeftBtn.Enabled = true;
                LeftBtn.BackColor = Color.White;
            }
            if (nPageCurrent == nPageAll)
            {
                RightBtn.Enabled = false;
                RightBtn.BackColor = Color.LightGray;
            }
            else
            {
                RightBtn.Enabled = true;
                RightBtn.BackColor = Color.White;
            }
        }

        private void SearchTxt_TextChanged(object sender, EventArgs e)
        {
            search = SearchTxt.Text;
            Podgotovka();
        }

        private void SortCmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            sort = SortCmb.Text;
            if (sortCount > 0)
                Podgotovka();
            sortCount++;
        }

        private void FiltrCmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            filtr = FiltrCmb.Text;
            if (filtrCount > 0) 
                Podgotovka();
            filtrCount++;
        }

        private void productDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return; 
            bool active = (bool)productDataGridView[5, e.RowIndex].Value;

            var cell = productDataGridView.Rows[e.RowIndex].Cells[5]; 

            if (active == false)
            {
                cell.Style.BackColor = Color.LightGray;
            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            AddEditProductFrm form = new AddEditProductFrm();
            form.prod = null;
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                Podgotovka();
            }
        }

        private void CostChangeBtn_Click(object sender, EventArgs e)
        {
            lstSelectedIdData.Clear();
            if (productDataGridView.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in productDataGridView.SelectedRows)
                {
                    lstSelectedIdData.Add(lstFormatData[row.Index].ID);
                }
                CostChangeFrm form = new CostChangeFrm();
                DialogResult dr = form.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    Podgotovka();
                }
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            Product prod = (Product)productBindingSource.Current;
            AddEditProductFrm form = new AddEditProductFrm();

            form.prod = prod;
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            { 
                Podgotovka();
            }
        }

        private void AttachedProductBtn_Click(object sender, EventArgs e)
        {
            Product prod = (Product)productBindingSource.Current;
            AttachedProductFrm form = new AttachedProductFrm();
            form.prod = prod;
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                Podgotovka();
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            Product prd = (Product)productBindingSource.Current;
            DialogResult dr = MessageBox.Show("Вы действительно хотите удалить товар - " + prd.Title,
               "Удаление товара", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {

                if (prd.ProductSales.Count > 0)
                {
                    MessageBox.Show("Данную продукцию удалить нельзя, т.к. есть данные о продажах!");
                    return;
                }
                if (prd.Product1.Count > 0)
                {
                    Program.db.Products.RemoveRange(prd.Product1);
                }
                Program.db.Products.Remove(prd);
                try
                {
                    Program.db.SaveChanges();
                    Podgotovka();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void SalesBtn_Click(object sender, EventArgs e)
        {
            Product prod = (Product)productBindingSource.Current;
            ProductSalesFrm form = new ProductSalesFrm();
            form.prd = prod;
            DialogResult dr = form.ShowDialog();
        }

        private void LeftBtn_Click(object sender, EventArgs e)
        {
            if (nPageCurrent > nPageFirst)
            {
                nPageCurrent--;
            }
            else if ((nPageCurrent == nPageFirst) && (nPageFirst > 1))
            {
                nPageFirst--;
                nPageCurrent = nPageFirst;             
            }
            ShowButtons(nPageFirst, nPageCurrent);          
            ShowData();
        }

        private void RightBtn_Click(object sender, EventArgs e)
        {
            if (nPageCurrent < nPageFirst + nButtons - 1)
            {
                nPageCurrent++;
            }
            else if (nPageCurrent < nPageAll)
            {
                nPageFirst++;
                nPageCurrent++;
            }
            ShowButtons(nPageFirst, nPageCurrent);
            ShowData();
        }

        private void productDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
    }
}
